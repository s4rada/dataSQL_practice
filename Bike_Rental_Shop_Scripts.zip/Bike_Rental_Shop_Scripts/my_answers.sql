
select * from customer;
select * from bike;
select * from rental;
select * from membership_type;
select * from membership;


--1
select category,count(*) as num_bikes from bike group by category having count(*) > 2 order by 2
--2
select c.name, count(m.id) from customer c 
left join 
membership m
on
c.id = m.customer_id
group by c.name 
having count(m.id)>2
order by 2 desc;
--3 
select lower(category), price_per_hour,price_per_day,
case 
	when category = 'mountain' then round((price_per_hour * 0.8),2)
	when category = 'electric' then round((price_per_hour * 0.9),2)
	else round((price_per_hour * 0.5),2) end as new_hourly_price,
case 
	when category = 'mountain' then round((price_per_hour * 0.8),2)
	when category = 'electric' then round((price_per_hour * 0.5),2)
	else round((price_per_hour * 0.5),2) end as new_daily_price
from bike group by category,price_per_hour,price_per_day
--4
select count(*) from bike where status = 'available';
select count(*) from bike where status = 'rented';

select 
count(*) filter( where status = 'available' ) as available_bike,
count(*) filter( where status = 'rented' ) as rented_bike
from bike

--5


select extract(year from start_timestamp),extract(month from start_timestamp), sum(total_paid) from rental group by extract(year from start_timestamp),extract(month from start_timestamp)
union all
select extract(year from start_timestamp),null as month, sum(total_paid) from rental group by extract(year from start_timestamp)
union all
select null as year,null as month, sum(total_paid) from rental order by 1,2;

--6

select * from customer;
select * from bike;
select * from rental;
select * from membership_type;
select * from membership;

select extract(year from m.start_date),
extract(month from m.start_date),
sum(m.total_paid), mt.name from membership m 
join membership_type mt on m.membership_type_id = mt.id group by 1,2,mt.name order by 1,2,mt.name 

--7
select * from customer;
select * from bike;
select * from rental;
select * from membership_type;
select * from membership;

select
extract(month from m.start_date),
sum(m.total_paid), mt.name from membership m 
join membership_type mt on m.membership_type_id = mt.id where extract(year from m.start_date) = 2023 
group by 1,mt.name order by 1,mt.name 

--8
select * from customer;
select * from bike;
select * from rental;
select * from membership_type;
select * from membership;

with cte as 
(
select m.customer_id, count(1),
case when count(1)> 10 then 'more than 10'
when count(1) between 5 and 10 then 'between 5 and 10'
else 'fewer than 5' end as category
from rental r 
join membership m on r.customer_id = m.customer_id 
join membership_type mt on m.membership_type_id = mt.id
group by m.customer_id
)
select category as rental_count_category, count(*) as customer_count 
from cte group by category order by customer_count

select * from customer;
select * from bike;
select * from rental;
select * from membership_type;
select * from membership;

with cte as 
(
select r.customer_id, count(*) count_num,
case when count(*) > 10 then 'more than 10'
when count(*) between 5 and 10 then 'between 5 and 10'
else 'less than 5' end as category
from rental r 
join membership m on m.customer_id = r.customer_id
group by r.customer_id
)
select category as rental_count_category, count(*) customer_count from cte group by category