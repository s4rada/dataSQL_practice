select * from city
select * from customers
select * from sales
select * from products


-- ## Objective
-- The goal of this project is to analyze the sales data of Monday Coffee, a company that has been selling its products online since January 2023, and to recommend the top three major cities in India for opening new coffee shop locations based on consumer demand and sales performance.

-- ## Key Questions
-- 1. **Coffee Consumers Count**  
--    How many people in each city are estimated to consume coffee, given that 25% of the population does?
select city_id, city_name, population, round(population * .25,0) population_coffee_drinkers from city

-- 2. **Total Revenue from Coffee Sales**  
--    What is the total revenue generated from coffee sales across all cities in the last quarter of 2023?

select ci.city_name, sum(s.total) revenue from sales s
join products p on s.product_id = p.product_id 
join customers c on c.customer_id = s.customer_id
join city ci on ci.city_id = c.city_id
where extract(quarter from sale_date) = 4 and extract(year from sale_date) = 2023
group by ci.city_name
order by 2 desc 
-- 3. **Sales Count for Each Product**  
--    How many units of each coffee product have been sold?

select p.product_name, count(*) from sales s
join products p on s.product_id = p.product_id
group by p.product_name
order by 2 desc
-- 4. **Average Sales Amount per City**  
--    What is the average sales amount per customer in each city?

select ci.city_name, sum(s.total)/count(distinct c.customer_id) avg_sales from sales s
join customers c on c.customer_id = s.customer_id
join city ci on ci.city_id = c.city_id
group by ci.city_id
order by 2 desc
-- 5. **City Population and Coffee Consumers**  
--    Provide a list of cities along with their populations and estimated coffee consumers.

select ci.city_name, ci.population, ci.population * .25 coffee_drinkers, count(distinct c.customer_id) coffee_customers from sales s
join customers c on c.customer_id = s.customer_id
join city ci on ci.city_id = c.city_id
group by ci.city_id

-- 6. **Top Selling Products by City**  
--    What are the top 3 selling products in each city based on sales volume?

with cte as (
select ci.city_name, p.product_name, count(s.sale_id) count_sales, rank() over(partition by ci.city_name order by count(s.sale_id)desc) rank_sales from sales s
join products p on s.product_id = p.product_id
join customers c on s.customer_id = c.customer_id
join city ci on ci.city_id = c.city_id
group by ci.city_name, p.product_name
)
select * from cte where rank_sales <= 3 ORDER BY 1,3 desc

-- 7. **Customer Segmentation by City**  
--    How many unique customers are there in each city who have purchased coffee products?
select ci.city_name, count(distinct c.*) from city ci
join customers c on ci.city_id = c.city_id
group by ci.city_name
-- 8. **Average Sale vs Rent**  
--    Find each city and their average sale per customer and avg rent per customer

SELECT 
    ci.city_name,
    SUM(s.total) / COUNT(DISTINCT c.customer_id) AS avg_sale_per_customer,
    ci.estimated_rent / COUNT(DISTINCT c.customer_id) AS rent_per_customer
FROM city ci
JOIN customers c ON ci.city_id = c.city_id
JOIN sales s ON s.customer_id = c.customer_id
GROUP BY ci.city_name, ci.estimated_rent
ORDER BY ci.city_name;
-- 9. **Monthly Sales Growth**  
--    Sales growth rate: Calculate the percentage growth (or decline) in sales over different time periods (monthly).

with cte as(
select extract(month from sale_date) months, extract(year from sale_date) years, sum(total) total_sales from sales
group by extract(month from sale_date),extract(year from sale_date)
)
select *, LAG(total_sales) OVER (PARTITION BY years ORDER BY months) from cte
order by 2,1

select extract(month from sale_date), extract(year from sale_date) from 
-- 10. **Market Potential Analysis**  
--     Identify top 3 city based on highest sales, return city name, total sale, total rent, total customers, estimated  coffee consumer
select * from city
select * from customers
select * from sales
select * from products
    
select ci.city_name, sum(s.total), ci.estimated_rent, count(c.*), population * 0.25 coffee_consumer from city ci
join customers c on c.city_id = ci.city_id
join sales s on s.customer_id = c.customer_id
group by 1,5,3
-- ## Recommendations
-- After analyzing the data, the recommended top three cities for new store openings are:

-- **City 1: Pune**  
-- 1. Average rent per customer is very low.  
-- 2. Highest total revenue.  
-- 3. Average sales per customer is also high.

-- **City 2: Delhi**  
-- 1. Highest estimated coffee consumers at 7.7 million.  
-- 2. Highest total number of customers, which is 68.  
-- 3. Average rent per customer is 330 (still under 500).

-- **City 3: Jaipur**  
-- 1. Highest number of customers, which is 69.  
-- 2. Average rent per customer is very low at 156.  
-- 3. Average sales per customer is better at 11.6k.