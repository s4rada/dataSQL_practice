create table stg_pan_numbers_dataset
(
	pan_number text
)

select * from stg_pan_numbers_dataset;

-- handle missing data
select * from stg_pan_numbers_dataset where pan_number is null
select * from stg_pan_numbers_dataset where pan_number is not null
-- handle duplicates
select *, count(*) from stg_pan_numbers_dataset group by 1 having count(*)>1 order by 2 asc
-- handle trailing spaces
select * from stg_pan_numbers_dataset where pan_number <> trim(pan_number)
select trim(pan_number) from stg_pan_numbers_dataset
-- handle lowercase
select * from stg_pan_numbers_dataset where pan_number <> upper(pan_number)
select upper(pan_number) from stg_pan_numbers_dataset



--cleaned data
select distinct trim(upper(pan_number)) as pan_number from stg_pan_numbers_dataset 
where pan_number is not null 
and 
trim(pan_number) <> ''

--VALIDATION--
--check if 10 chars long
--function to check if adjacent characters are the same
create or replace function fn_check_adjacent_characters(p_str text)
returns boolean
language plpgsql
as $$
begin
	for i in 1 .. (length(p_str)-1)
	loop
		if substring(p_str, i, 1) = substring(p_str, i + 1, 1)
		then 
			return true;
		end if;
	end loop;
	return false;
end;
$$

select fn_check_adjacent_characters('ASDFG')

--function to check if characters are in sequence
create or replace function fn_check_sequential_characters(p_str text)
returns boolean
language plpgsql
as $$
begin
	for i in 1 .. (length(p_str)-1)
	loop
		if ascii(substring(p_str, i+1, 1)) - ascii(substring(p_str, i, 1)) <> 1
		then 
			return false;
		end if;
	end loop;
	return true;
end;
$$
select fn_check_sequential_characters('12345')

--REG EXP to validate pattern
select * from stg_pan_numbers_dataset where pan_number ~ '^[A-Z]{5}[0-9]{4}[A-Z]{1}'

--Categorization check if valid/invalid
create or replace view vw_cleaned
as
with cte_cleaned_pan as 
		(
		select distinct trim(upper(pan_number)) as pan_number from stg_pan_numbers_dataset 
		where pan_number is not null 
		and 
		trim(pan_number) <> ''
		),
	cte_valid_pans as
		(select * from cte_cleaned_pan
		where fn_check_adjacent_characters(pan_number) = false
		and 
		fn_check_sequential_characters(substring(pan_number,1,5)) = false 
		and
		fn_check_sequential_characters(substring(pan_number,6,4)) = false 
		and pan_number ~ '^[A-Z]{5}[0-9]{4}[A-Z]{1}')
	select cln.pan_number, case when vld.pan_number is not null then 'valid' else 'invalid' end as status
	from cte_cleaned_pan cln
	left join cte_valid_pans vld on vld.pan_number = cln.pan_number;

--summary report
stg_pan_numbers_dataset
vw_cleaned
with cte as
	(select 
		(select count(*) from stg_pan_numbers_dataset) as total_records,
		count(*) filter(where status = 'valid') as TOTAL_VALID,
		count(*) filter(where status = 'invalid') as TOTAL_INVALID
	from vw_cleaned)
select total_records,TOTAL_VALID,TOTAL_INVALID,(total_records-(TOTAL_VALID+TOTAL_INVALID)) as total_null_val from cte
