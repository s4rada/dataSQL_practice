
-- What are the different payment methods, and how many transactions and
-- items were sold with each method?
select payment_method, count(*) num_payments from walmart_data group by payment_method
-- Which category received the highest average rating in each branch?
with cte as(
select branch, category, avg(rating), rank() over(partition by branch order by avg(rating) desc) rank
from walmart_data 
group by 1,2
order by 1
)
select * from cte where rank = 1
-- What is the busiest day of the week for each branch based on transaction
-- volume?
with cte as (
SELECT 
    branch,
    EXTRACT(DOW FROM TO_DATE(date, 'DD/MM/YY')) as day_of_week_number,
    CASE EXTRACT(DOW FROM TO_DATE(date, 'DD/MM/YY'))
        WHEN 0 THEN 'Sunday'
        WHEN 1 THEN 'Monday'
        WHEN 2 THEN 'Tuesday'
        WHEN 3 THEN 'Wednesday'
        WHEN 4 THEN 'Thursday'
        WHEN 5 THEN 'Friday'
        WHEN 6 THEN 'Saturday'
    END as day_of_week_name,
    SUM(CAST(REPLACE(unit_price, '$', '') AS DECIMAL(10,2)) * 
        CAST(quantity AS DECIMAL(10,2))) as total_sales,
	rank() over(partition by branch order by SUM(CAST(REPLACE(unit_price, '$', '') AS DECIMAL(10,2)) * 
        CAST(quantity AS DECIMAL(10,2))) desc )
FROM walmart_data
WHERE date IS NOT NULL
GROUP BY branch, EXTRACT(DOW FROM TO_DATE(date, 'DD/MM/YY'))
ORDER BY branch, day_of_week_number)
select * from cte where rank = 1
-- How many items were sold through each payment method?
select payment_method, sum(quantity::integer) 
from walmart_data 
group by 1
order by 2 desc
-- What are the average, minimum, and maximum ratings for each category in
-- each city?
select city, category, round(avg(rating),2) avg_rating, min(rating) min_rating, max(rating) max_rating 
from walmart_data
group by 1,2
order by 1

-- What is the total profit for each category, ranked from highest to lowest?
select category, sum(profit_margin) sum_profit, rank() over(order by sum(profit_margin) desc)
from walmart_data
group by 1
order by 2 desc

-- What is the most frequently used payment method in each branch?
with cte as (
select branch, payment_method, count(*), rank() over(partition by branch order by count(*) desc) 
from walmart_data
group by 1,2)
select * from cte where rank = 1
order by 1


-- How many transactions occur in each shift (Morning, Afternoon, Evening)
-- across branches?
select
case 
when extract(hour from time::time) between 6 and 12 then 'Morning'
when extract(hour from time::time) between 12 and 18 then 'Afternoon'
when extract(hour from time::time) between 18 and 24 then 'Evening'
end as time_of_day,
count(*)
from walmart_data
group by time_of_day

-- Which branches experienced the largest decrease in revenue compared to
-- the previous year?

select * from walmart_data


with cte as (
select branch, sum((replace(unit_price, '$','')::float)*quantity) total_revenue
from walmart_data where extract(year from to_date(date,'DD/MM/YY')) = 2022
group by branch
),
cte2 as (
select branch, sum((replace(unit_price, '$','')::float)*quantity) total_revenue
from walmart_data where extract(year from to_date(date,'DD/MM/YY')) = 2023
group by branch
)
select *,
case 
when cte.total_revenue > cte2.total_revenue
	then '-' || (cte.total_revenue - cte2.total_revenue)::text
when cte.total_revenue < cte2.total_revenue
	then '+' || (cte2.total_revenue - cte1.total_revenue)::text
end as "+/-"
from cte 
join cte2 on cte.branch = cte2.branch
order by 1



WITH cte AS (
    SELECT 
        branch, 
        SUM((REPLACE(unit_price, '$','')::FLOAT) * quantity) as total_revenue
    FROM walmart_data 
    WHERE EXTRACT(YEAR FROM TO_DATE(date,'DD/MM/YY')) = 2022
    GROUP BY branch
),
cte2 AS (
    SELECT 
        branch, 
        SUM((REPLACE(unit_price, '$','')::FLOAT) * quantity) as total_revenue
    FROM walmart_data 
    WHERE EXTRACT(YEAR FROM TO_DATE(date,'DD/MM/YY')) = 2023
    GROUP BY branch
)
SELECT 
    cte.branch,
    cte.total_revenue as total_revenue_2022,
    cte2.total_revenue as total_revenue_2023,
    CASE 
        WHEN cte.total_revenue > cte2.total_revenue
            THEN '-' || (cte.total_revenue - cte2.total_revenue)::TEXT
        WHEN cte.total_revenue < cte2.total_revenue
            THEN '+' || (cte2.total_revenue - cte.total_revenue)::TEXT
    END as "+/-"
FROM cte 
JOIN cte2 ON cte.branch = cte2.branch
ORDER BY 1;
