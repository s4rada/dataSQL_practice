import pandas as pd
import os

# Simple CSV to SQL converter
csv_file = "/Users/ron/Documents/data-practice/Walmart_SQL_Python-main/Walmart.csv"
sql_file = "/Users/ron/Documents/data-practice/Walmart_SQL_Python-main/Walmart.sql"

# Read CSV
df = pd.read_csv(csv_file)

# Clean column names for SQL
df.columns = [col.replace(' ', '_').replace('-', '_').replace('(', '').replace(')', '').lower() 
              for col in df.columns]

# Create SQL content
sql_content = []

# CREATE TABLE
table_name = "walmart_data"
columns = []
for col in df.columns:
    # Simple type inference
    if df[col].dtype == 'int64':
        col_type = "INTEGER"
    elif df[col].dtype == 'float64':
        col_type = "DECIMAL(10,2)"
    else:
        col_type = "TEXT"
    columns.append(f"    {col} {col_type}")

create_table = f"CREATE TABLE {table_name} (\n" + ",\n".join(columns) + "\n);\n"
sql_content.append(create_table)

# INSERT statements
for _, row in df.iterrows():
    values = []
    for val in row:
        if pd.isna(val):
            values.append("NULL")
        elif isinstance(val, str):
            values.append(f"'{val.replace("'", "''")}'")
        elif isinstance(val, (int, float)):
            values.append(str(val))
        else:
            values.append(f"'{str(val)}'")
    
    insert_stmt = f"INSERT INTO {table_name} VALUES (" + ", ".join(values) + ");"
    sql_content.append(insert_stmt)

# Write to file
with open(sql_file, 'w') as f:
    f.write('\n'.join(sql_content))

print(f"✅ SQL file created: {sql_file}")
print(f"📊 {len(df)} rows converted to SQL")