import pandas as pd
import os

# File paths
csv_file = '/Users/ron/Documents/data-practice/Spotify/najirh-Spotify-Data-Analysis-using-SQL-main/cleaned_dataset.csv'
sql_file = '/Users/ron/Documents/data-practice/Spotify/spotify_data.sql'

# Read CSV file
df = pd.read_csv(csv_file)

# Get column names and data types
print("Column names and sample data:")
for col in df.columns:
    print(f"{col}: {df[col].dtype}, Sample: {df[col].iloc[0] if len(df) > 0 else 'N/A'}")

# Generate CREATE TABLE statement
table_name = "spotify_tracks"

create_table_sql = f"CREATE TABLE {table_name} (\n"
for col in df.columns:
    dtype = df[col].dtype
    if dtype == 'object':
        sql_type = 'TEXT'
    elif dtype in ['int64', 'int32']:
        sql_type = 'INTEGER'
    elif dtype in ['float64', 'float32']:
        sql_type = 'REAL'
    else:
        sql_type = 'TEXT'
    create_table_sql += f"    {col} {sql_type},\n"

create_table_sql = create_table_sql.rstrip(',\n') + "\n);"

# Generate INSERT statements
insert_statements = []
for _, row in df.iterrows():
    columns = ', '.join(df.columns)
    values = ', '.join([f"'{str(value).replace("'", "''")}'" if pd.notna(value) else 'NULL' 
                       for value in row])
    insert_statements.append(f"INSERT INTO {table_name} ({columns}) VALUES ({values});")

# Write to SQL file
with open(sql_file, 'w') as f:
    f.write("-- Spotify Dataset SQL File\n")
    f.write("-- Generated from cleaned_dataset.csv\n\n")
    f.write(create_table_sql + "\n\n")
    f.write("-- Insert data\n")
    for insert_stmt in insert_statements:
        f.write(insert_stmt + "\n")

print(f"SQL file generated: {sql_file}")
print(f"Rows processed: {len(df)}")