-- ### Easy Level
-- 1. Retrieve the names of all tracks that have more than 1 billion streams.
select track from spotify_tracks where (stream::integer)>1000000000
-- 2. List all albums along with their respective artists.
select album, artist from spotify_tracks
-- 3. Get the total number of comments for tracks where `licensed = TRUE`.
select (select count(*) from spotify_tracks where licensed = 'TRUE') count_lic_true

-- 4. Find all tracks that belong to the album type `single`.
select track from spotify_tracks where album_type = 'single'
-- 5. Count the total number of tracks by each artist.
select artist, count(*) from spotify_tracks group by artist
-- ### Medium Level
-- 1. Calculate the average danceability of tracks in each album.
select album, avg(danceability::float), dense_rank() over(order by avg(danceability::float) desc) from spotify_tracks group by album
-- 2. Find the top 5 tracks with the highest energy values.
select track, energy, rank()over(order by energy::float desc ) from spotify_tracks limit 5

-- 3. List all tracks along with their views and likes where `official_video = TRUE`.
select track, views, likes from spotify_tracks where official_video = 'TRUE'

-- 4. For each album, calculate the total views of all associated tracks.
select album, sum(views) from spotify_tracks group by album order by 2 desc

-- 5. Retrieve the track names that have been streamed on Spotify more than YouTube.
select track, most_playedon from spotify_tracks where most_playedon = 'Spotify'

-- ### Advanced Level
-- 1. Find the top 3 most-viewed tracks for each artist using window functions.
with cte as 
(select artist, track, sum(views::integer), dense_rank()over(partition by artist order by sum(views::integer) desc) col_rank from spotify_tracks group by artist, track) 
select * from cte where col_rank<=3 

-- 2. Write a query to find tracks where the liveness score is above the average.
with cte as
(select track, (liveness::float) as liveness, avg(liveness::float) over() as avg_liveness from spotify_tracks )
select * from cte where liveness > avg_liveness 

-- 3. **Use a `WITH` clause to calculate the difference between the highest and lowest energy values for tracks in each album.**
select album, max(energy), min(energy) from spotify_tracks group by album
-- 5. Find tracks where the energy-to-liveness ratio is lesser than 1.2.
with cte as (
select album, max(energy) max_en, min(energy) min_en from spotify_tracks group by album
),
cte2 as (
select *, max_en - min_en as en_difference from cte 
)
select * from cte2 where en_difference < 1.2
-- 6. Calculate the cumulative sum of likes for tracks ordered by the number of views, using window functions.
select track, sum(likes::integer) over(order by (views::integer) desc) from spotify_tracks 