select * from zepto_data

-- 3. 🔍 Data Exploration
-- Counted the total number of records in the dataset
select count(*) total_records from zepto_data
-- Viewed a sample of the dataset to understand structure and content
select * from zepto_data
-- Checked for null values across all columns
-- Count rows where all columns are NULL
-- This will return an empty result if there are NO NULLs in the column

-- Identified distinct product categories available in the dataset
select distinct category from zepto_data

-- Compared in-stock vs out-of-stock product counts
select (select count(*) from zepto_data where outofstock = 'false') In_stock_count, (select count(*) from zepto_data where outofstock = 'true') Out_of_stock_count

-- Detected products present multiple times, representing different SKUs
select name, count(name) from zepto_data group by name

-- 4. 🧹 Data Cleaning
-- Identified and removed rows where MRP or discounted selling price was zero
select * from zepto_data where MRP <> '0' or discountedsellingprice <> '0'

-- Converted mrp and discountedSellingPrice from paise to rupees for consistency and readability
ALTER TABLE zepto_data 
ALTER COLUMN MRP TYPE INTEGER 
USING MRP::INTEGER;

ALTER TABLE zepto_data 
ALTER COLUMN discountedsellingprice TYPE float 
USING discountedsellingprice::float;


update zepto_data
set mrp = mrp/100.0;

update zepto_data
set discountedsellingprice = discountedsellingprice / 100.0;

select * from zepto_data
-- 5. 📊 Business Insights
-- Found top 10 best-value products based on discount percentage
select  distinct name, discountpercent 
from zepto_data 
order by discountpercent desc
limit 10
-- Identified high-MRP products that are currently out of stock
select distinct name, mrp 
from zepto_data 
where outofstock = 'true'
order by mrp desc
limit 10
-- Estimated potential revenue for each product category
select category, sum(quantity::integer) * sum(mrp) 
from zepto_data
group by category

-- Filtered expensive products (MRP > ₹500) with minimal discount
select name, mrp, discountpercent 
from zepto_data 
where mrp > 500 and discountpercent::integer <> 0
order by 3 
limit 10

-- Ranked top 5 categories offering highest average discounts
select category, avg(discountpercent::float) 
from zepto_data
group by category
order by 2 desc
-- Calculated price per gram to identify value-for-money products
select name,mrp, weightingms, mrp::float/weightingms::integer value_for_money
from zepto_data
where weightingms::integer <> 0
order by 4 desc
-- Grouped products based on weight into Low, Medium, and Bulk categories
select * from zepto_data
-- Measured total inventory weight per product category
select * from zepto_data
