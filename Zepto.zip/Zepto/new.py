import pandas as pd
import csv

def csv_to_postgresql_sql(csv_file_path, sql_file_path, table_name="zepto_data"):
    # Read CSV
    df = pd.read_csv(csv_file_path, encoding='cp1252')  # or 'latin-1' if cp1252 fails
    
    # Create SQL file
    with open(sql_file_path, 'w', encoding='utf-8') as f:
        # Generate CREATE TABLE with PostgreSQL data types
        create_table = f"CREATE TABLE {table_name} (\n"
        
        for col in df.columns:
            # Determine PostgreSQL data type based on column data
            col_data = df[col].dropna()
            
            if col_data.empty:
                pg_type = "TEXT"  # Default to TEXT if no data
            elif pd.api.types.is_integer_dtype(df[col]):
                pg_type = "INTEGER"
            elif pd.api.types.is_float_dtype(df[col]):
                pg_type = "DECIMAL"
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                pg_type = "TIMESTAMP"
            elif df[col].astype(str).str.len().max() > 255:
                pg_type = "TEXT"
            else:
                pg_type = "VARCHAR(255)"
            
            create_table += f"    {col} {pg_type},\n"
        
        create_table = create_table.rstrip(',\n') + "\n);\n\n"
        f.write(create_table)
        
        # Generate INSERT statements
        for _, row in df.iterrows():
            values = []
            for val in row:
                if pd.isna(val):
                    values.append("NULL")
                elif isinstance(val, str):
                    # Escape single quotes for PostgreSQL
                    val_escaped = val.replace("'", "''")
                    values.append(f"'{val_escaped}'")
                elif isinstance(val, (int, float)):
                    values.append(str(val))
                else:
                    val_escaped = str(val).replace("'", "''")
                    values.append(f"'{val_escaped}'")
            
            insert_sql = f"INSERT INTO {table_name} VALUES ({', '.join(values)});\n"
            f.write(insert_sql)
    
    print(f"PostgreSQL SQL file created: {sql_file_path}")
    print(f"Table: {table_name}")
    print(f"Rows: {len(df)}")

# Usage
csv_to_postgresql_sql(
    '/Users/ron/Documents/data-practice/Zepto/zepto_v2.csv',
    'zepto_postgres.sql',
    'zepto_data'
)