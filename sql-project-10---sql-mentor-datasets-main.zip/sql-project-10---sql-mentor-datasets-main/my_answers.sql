-- ### Q1. List All Distinct Users and Their Stats
-- - **Description**: Return the user name, total submissions, and total points earned by each user.
-- - **Expected Output**: A list of users with their submission count and total points.
select user_id, count(user_id), sum(points) 
from user_subscriptions 
group by user_id
order  by 2 desc

-- ### Q2. Calculate the Daily Average Points for Each User
-- - **Description**: For each day, calculate the average points earned by each user.
-- - **Expected Output**: A report showing the average points per user for each day.
select user_id,  submitted_at::date, round(avg(points),2) 
from user_subscriptions
group by 1,2
order by 2 


-- ### Q3. Find the Top 3 Users with the Most Correct Submissions for Each Day
-- - **Description**: Identify the top 3 users with the most correct submissions for each day.
-- - **Expected Output**: A list of users and their correct submissions, ranked daily.
WITH daily_counts AS (
    -- Count how many correct submissions each user has per day
    SELECT 
        DATE(submitted_at) as submission_day,
        username,
        user_id,
        COUNT(*) as submissions_count  -- Count rows (correct submissions)
    FROM user_subscriptions
    WHERE points > 0  -- Filter for correct submissions
    GROUP BY DATE(submitted_at), username, user_id
    -- Now we have: day, user, how many correct submissions they had
),
ranked_daily AS (
    -- Rank users within each day
    SELECT 
        submission_day,
        username,
        user_id,
        submissions_count,
        ROW_NUMBER() OVER(
            PARTITION BY submission_day 
            ORDER BY submissions_count DESC
        ) as daily_rank
    FROM daily_counts
)
-- Show top 3 ranked users per day
SELECT 
    submission_day as "Date",
    daily_rank as "Rank",
    username as "Username",
    user_id as "User ID",
    submissions_count as "Correct Submissions"
FROM ranked_daily
WHERE daily_rank <= 3
ORDER BY submission_day asc, daily_rank;
-- ### Q4. Find the Top 5 Users with the Highest Number of Incorrect Submissions
-- - **Description**: Identify the top 5 users with the highest number of incorrect submissions.
-- - **Expected Output**: A list of users with the count of incorrect submissions.
select username, user_id, count(*) from user_subscriptions
where points < 0
group by user_id, username
order by 3 desc limit 5

-- ### Q5. Find the Top 10 Performers for Each Week
-- - **Description**: Identify the top 10 users with the highest total points earned each week.
-- - **Expected Output**: A report showing the top 10 users ranked by total points per week.
with cte as (
select extract(week from submitted_at::date),username,user_id, sum(points), rank() over(partition by (extract(week from submitted_at::date)) order by sum(points) desc) top_10
from user_subscriptions
group by user_id, extract(week from submitted_at::date),username
order by 1 )
select * from cte where top_10 <= 10



