import pandas as pd
import csv
from datetime import datetime

def analyze_csv_structure(csv_path, num_rows=100):
    """
    Analyze CSV structure to understand data types
    """
    print(f"📊 Analyzing CSV structure: {csv_path}")
    print("=" * 70)
    
    try:
        # Read the CSV
        df = pd.read_csv(csv_path, nrows=num_rows)
        
        print(f"✅ File loaded successfully")
        print(f"   Total columns found: {len(df.columns)}")
        print(f"   Sample rows analyzed: {min(num_rows, len(df))}")
        
        print("\n📋 COLUMN ANALYSIS:")
        print("-" * 70)
        
        column_analysis = []
        
        for i, col in enumerate(df.columns, 1):
            col_data = df[col].dropna()
            non_null_count = len(col_data)
            null_count = len(df) - non_null_count
            
            # Try to infer data type
            if col_data.empty:
                inferred_type = "TEXT"
                sample_values = ["No data"]
            else:
                # Check if it's numeric
                try:
                    numeric_vals = pd.to_numeric(col_data, errors='coerce')
                    if numeric_vals.notna().all():
                        if (numeric_vals.astype(float) == numeric_vals.astype(int)).all():
                            # Check range for integer type
                            max_val = numeric_vals.max()
                            min_val = numeric_vals.min()
                            if min_val >= -32768 and max_val <= 32767:
                                inferred_type = "SMALLINT"
                            elif min_val >= -2147483648 and max_val <= 2147483647:
                                inferred_type = "INTEGER"
                            else:
                                inferred_type = "BIGINT"
                        else:
                            inferred_type = "DECIMAL(10,2)"
                    else:
                        # Check if it's date-like
                        try:
                            date_vals = pd.to_datetime(col_data, errors='coerce')
                            if date_vals.notna().any():
                                # Check if it's date only
                                has_time = any(pd.notna(v) and v.hour + v.minute + v.second > 0 for v in date_vals)
                                if has_time:
                                    inferred_type = "TIMESTAMP"
                                else:
                                    inferred_type = "DATE"
                            else:
                                # Check for boolean
                                unique_str = col_data.astype(str).str.lower().unique()
                                bool_values = {'true', 'false', '1', '0', 'yes', 'no', 'y', 'n'}
                                if set(unique_str).issubset(bool_values):
                                    inferred_type = "BOOLEAN"
                                else:
                                    # Check string length
                                    max_len = col_data.astype(str).str.len().max()
                                    if max_len < 255:
                                        inferred_type = f"VARCHAR({min(255, max_len + 20)})"
                                    else:
                                        inferred_type = "TEXT"
                        except:
                            inferred_type = "TEXT"
                except:
                    inferred_type = "TEXT"
            
            sample_values = col_data.head(3).tolist()
            if len(sample_values) < 3 and null_count > 0:
                sample_values.append(f"[{null_count} NULLs]")
            
            column_analysis.append({
                'name': col,
                'type': inferred_type,
                'non_null': non_null_count,
                'null': null_count,
                'sample': sample_values
            })
            
            print(f"{i:2d}. {col:30} {inferred_type:20}")
            print(f"    Sample: {sample_values}")
            print(f"    Non-null: {non_null_count}, Null: {null_count}")
            print()
        
        # Check total rows in file
        with open(csv_path, 'r', encoding='utf-8') as f:
            total_rows = sum(1 for line in f) - 1  # Subtract header
        
        print(f"\n📈 FILE SUMMARY:")
        print(f"   Total rows in file: {total_rows:,}")
        print(f"   Total columns: {len(df.columns)}")
        
        return column_analysis, total_rows, df.columns.tolist()
        
    except Exception as e:
        print(f"❌ Error analyzing CSV: {str(e)}")
        return None, 0, []

def csv_to_sql_safe(csv_path, output_sql_path, table_name='user_subscriptions'):
    """
    Convert CSV to SQL with safe data type handling
    """
    print(f"\n🚀 Converting CSV to SQL...")
    print("=" * 70)
    
    try:
        # First analyze the CSV
        column_analysis, total_rows, columns = analyze_csv_structure(csv_path)
        if not column_analysis:
            return False
        
        # Read the entire CSV with proper handling
        print(f"\n📖 Reading entire CSV file ({total_rows:,} rows)...")
        df = pd.read_csv(csv_path, dtype=str)  # Read all as string initially
        print(f"✅ CSV loaded: {len(df)} rows")
        
        # Create SQL file
        with open(output_sql_path, 'w', encoding='utf-8') as sql_file:
            # Write header
            sql_file.write(f"-- SQL file generated from: {csv_path}\n")
            sql_file.write(f"-- Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            sql_file.write(f"-- Table: {table_name}\n")
            sql_file.write(f"-- Total rows: {total_rows:,}\n")
            sql_file.write("--\n\n")
            
            # DROP TABLE
            sql_file.write(f"DROP TABLE IF EXISTS {table_name} CASCADE;\n\n")
            
            # CREATE TABLE with analyzed types
            sql_file.write(f"CREATE TABLE {table_name} (\n")
            
            column_defs = []
            for col_info in column_analysis:
                col_def = f'    "{col_info["name"]}" {col_info["type"]}'
                column_defs.append(col_def)
            
            sql_file.write(",\n".join(column_defs))
            sql_file.write("\n);\n\n")
            
            # Prepare INSERT statements
            print(f"\n✍️  Generating INSERT statements...")
            sql_file.write("-- INSERT statements\n")
            
            # Process in batches
            batch_size = 500
            processed_rows = 0
            
            for start_idx in range(0, len(df), batch_size):
                end_idx = min(start_idx + batch_size, len(df))
                batch = df.iloc[start_idx:end_idx]
                
                insert_values = []
                for _, row in batch.iterrows():
                    row_values = []
                    for col in columns:
                        value = row[col]
                        
                        # Handle NULLs
                        if pd.isna(value) or str(value).strip() == '':
                            row_values.append('NULL')
                        else:
                            # Clean the value
                            clean_value = str(value).strip()
                            
                            # Find column type
                            col_info = next((c for c in column_analysis if c['name'] == col), None)
                            col_type = col_info['type'] if col_info else 'TEXT'
                            
                            # Format based on type
                            if 'INT' in col_type or 'DECIMAL' in col_type or 'NUMERIC' in col_type:
                                # Numeric types - just use the value
                                try:
                                    # Try to convert to validate
                                    float_val = float(clean_value)
                                    row_values.append(str(float_val))
                                except:
                                    # If conversion fails, use as string with quotes
                                    clean_value = clean_value.replace("'", "''")
                                    row_values.append(f"'{clean_value}'")
                            elif 'DATE' in col_type or 'TIME' in col_type or 'TIMESTAMP' in col_type:
                                # Date/time types
                                try:
                                    # Try to parse as date
                                    if '/' in clean_value:
                                        # Handle different date formats
                                        if clean_value.count('/') == 2:
                                            parts = clean_value.split('/')
                                            if len(parts[0]) == 4:  # YYYY/MM/DD
                                                date_obj = datetime.strptime(clean_value, '%Y/%m/%d')
                                            else:  # MM/DD/YYYY
                                                date_obj = datetime.strptime(clean_value, '%m/%d/%Y')
                                        else:
                                            date_obj = datetime.strptime(clean_value, '%Y-%m-%d')
                                    elif '-' in clean_value:
                                        date_obj = datetime.strptime(clean_value, '%Y-%m-%d')
                                    else:
                                        # If it's not a proper date, check if it's numeric
                                        try:
                                            num_val = int(clean_value)
                                            # If it's a number like "60", it's probably not a date
                                            # Use it as-is but warn
                                            print(f"⚠️  Warning: Column '{col}' has value '{clean_value}' which looks like a number but column is typed as {col_type}")
                                            row_values.append(f"'{clean_value}'")
                                            continue
                                        except:
                                            date_obj = datetime.strptime(clean_value, '%Y%m%d')
                                    
                                    if 'TIMESTAMP' in col_type:
                                        formatted_date = date_obj.strftime("'%Y-%m-%d %H:%M:%S'")
                                    else:
                                        formatted_date = date_obj.strftime("'%Y-%m-%d'")
                                    row_values.append(formatted_date)
                                except Exception as e:
                                    # If date parsing fails, use as string
                                    print(f"⚠️  Date parsing error for '{col}': {clean_value} - {str(e)}")
                                    clean_value = clean_value.replace("'", "''")
                                    row_values.append(f"'{clean_value}'")
                            elif 'BOOLEAN' in col_type:
                                # Boolean types
                                clean_lower = clean_value.lower()
                                if clean_lower in ['true', '1', 'yes', 'y']:
                                    row_values.append('TRUE')
                                elif clean_lower in ['false', '0', 'no', 'n']:
                                    row_values.append('FALSE')
                                else:
                                    row_values.append(f"'{clean_value}'")
                            else:
                                # String types
                                clean_value = clean_value.replace("'", "''")
                                row_values.append(f"'{clean_value}'")
                    
                    insert_values.append("(" + ", ".join(row_values) + ")")
                
                # Write batch INSERT
                if insert_values:
                    insert_sql = f"INSERT INTO {table_name} ({', '.join([f'\"{col}\"' for col in columns])}) VALUES\n"
                    insert_sql += ",\n".join(insert_values) + ";\n\n"
                    sql_file.write(insert_sql)
                
                processed_rows += len(batch)
                if processed_rows % 1000 == 0:
                    print(f"  Processed {processed_rows:,} rows...")
            
            sql_file.write(f"-- End of data import\n")
            sql_file.write(f"-- Total rows inserted: {processed_rows}\n")
        
        print(f"\n✅ SQL file created successfully: {output_sql_path}")
        print(f"✅ Total rows processed: {processed_rows:,}")
        
        # Show import instructions
        print("\n" + "=" * 70)
        print("📝 IMPORT INSTRUCTIONS:")
        print("=" * 70)
        print(f"1. Create database (if not exists):")
        print(f"   CREATE DATABASE your_database;")
        print(f"\n2. Import the SQL file:")
        print(f"   psql -U your_username -d your_database -f {output_sql_path}")
        print(f"\n3. Or set DateStyle first (if still getting date errors):")
        print(f"   SET DateStyle = 'ISO, MDY';")
        print(f"   \\i {output_sql_path}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def create_fallback_sql(csv_path, output_sql_path, table_name='user_subscriptions'):
    """
    Create a fallback SQL file that treats all columns as TEXT initially
    """
    print(f"\n🔄 Creating fallback SQL (all TEXT columns)...")
    
    try:
        df = pd.read_csv(csv_path, dtype=str)
        
        with open(output_sql_path, 'w', encoding='utf-8') as sql_file:
            sql_file.write(f"-- FALLBACK SQL - All columns as TEXT\n")
            sql_file.write(f"-- Generated from: {csv_path}\n")
            sql_file.write(f"-- Table: {table_name}\n")
            sql_file.write(f"-- Rows: {len(df):,}\n")
            sql_file.write("--\n\n")
            
            # DROP TABLE
            sql_file.write(f"DROP TABLE IF EXISTS {table_name} CASCADE;\n\n")
            
            # CREATE TABLE (all TEXT)
            sql_file.write(f"CREATE TABLE {table_name} (\n")
            columns = df.columns.tolist()
            col_defs = [f'    "{col}" TEXT' for col in columns]
            sql_file.write(",\n".join(col_defs))
            sql_file.write("\n);\n\n")
            
            # INSERT statements
            sql_file.write("-- INSERT statements\n")
            
            batch_size = 1000
            for start_idx in range(0, len(df), batch_size):
                end_idx = min(start_idx + batch_size, len(df))
                batch = df.iloc[start_idx:end_idx]
                
                insert_values = []
                for _, row in batch.iterrows():
                    row_values = []
                    for val in row:
                        if pd.isna(val) or str(val).strip() == '':
                            row_values.append('NULL')
                        else:
                            clean_val = str(val).replace("'", "''")
                            row_values.append(f"'{clean_val}'")
                    insert_values.append("(" + ", ".join(row_values) + ")")
                
                if insert_values:
                    insert_sql = f"INSERT INTO {table_name} ({', '.join([f'\"{col}\"' for col in columns])}) VALUES\n"
                    insert_sql += ",\n".join(insert_values) + ";\n\n"
                    sql_file.write(insert_sql)
                
                if start_idx % 5000 == 0:
                    print(f"  Processed {min(start_idx + batch_size, len(df)):,} rows...")
            
            sql_file.write(f"-- Total rows: {len(df):,}\n")
        
        print(f"✅ Fallback SQL created: {output_sql_path}")
        print(f"\n💡 After importing, you can alter column types:")
        print(f"   ALTER TABLE {table_name} ALTER COLUMN column_name TYPE integer USING column_name::integer;")
        
        return True
        
    except Exception as e:
        print(f"❌ Error creating fallback: {str(e)}")
        return False

# Main execution
if __name__ == "__main__":
    csv_path = '/Users/ron/Documents/data-practice/sql-project-10---sql-mentor-datasets-main/user_sub_sql_mentor06nov.csv'
    
    print("=" * 70)
    print("CSV TO SQL CONVERTER (WITH ERROR HANDLING)")
    print("=" * 70)
    
    # Try the smart converter first
    output_sql = '/Users/ron/Documents/data-practice/user_subscriptions_smart.sql'
    
    print("\n🔧 Attempt 1: Smart conversion with type inference")
    print("-" * 70)
    
    success = csv_to_sql_safe(csv_path, output_sql, 'user_subscriptions')
    
    if not success:
        print("\n" + "=" * 70)
        print("🔄 Attempt 2: Fallback conversion (all TEXT columns)")
        print("-" * 70)
        
        fallback_sql = '/Users/ron/Documents/data-practice/user_subscriptions_fallback.sql'
        success = create_fallback_sql(csv_path, fallback_sql, 'user_subscriptions')
    
    print("\n" + "=" * 70)
    print("✅ CONVERSION COMPLETE")
    print("=" * 70)