import pandas as pd
import os

files = ['artist', 'canvas_size', 'image_link', 'museum_hours', 'museum', 'product_size', 'subject', 'work']

# Create SQL file
sql_file_path = '/Users/ron/Documents/data-practice/painting_data.sql'
with open(sql_file_path, 'w') as sql_file:
    sql_file.write("-- Painting Database SQL Export\n")
    sql_file.write("-- Generated from CSV files\n\n")
    
    for file in files:
        csv_path = f'/Users/ron/Documents/data-practice/Scripts_SQL_Casestudy_Paintings/archive/{file}.csv'
        df = pd.read_csv(csv_path)
        
        # Write table creation SQL
        sql_file.write(f"-- Table: {file}\n")
        sql_file.write(f"DROP TABLE IF EXISTS {file};\n")
        sql_file.write(f"CREATE TABLE {file} (\n")
        
        # Generate column definitions
        columns = []
        for col in df.columns:
            dtype = str(df[col].dtype)
            if 'int' in dtype:
                sql_type = 'INTEGER'
            elif 'float' in dtype:
                sql_type = 'REAL'
            elif 'bool' in dtype:
                sql_type = 'BOOLEAN'
            else:
                sql_type = 'TEXT'
            columns.append(f"    {col} {sql_type}")
        
        sql_file.write(",\n".join(columns))
        sql_file.write("\n);\n\n")
        
        # Write INSERT statements
        sql_file.write(f"-- Data for {file}\n")
        for index, row in df.iterrows():
            values = []
            for val in row:
                if pd.isna(val):
                    values.append('NULL')
                elif isinstance(val, (int, float)):
                    values.append(str(val))
                else:
                    # Escape single quotes in strings
                    escaped_val = str(val).replace("'", "''")
                    values.append(f"'{escaped_val}'")
            
            sql_file.write(f"INSERT INTO {file} ({', '.join(df.columns)}) VALUES ({', '.join(values)});\n")
        
        sql_file.write("\n" + "="*80 + "\n\n")

print(f"SQL file created successfully at: {sql_file_path}")