--1
select * from work where museum_id is null
--2
select m.name, count(*) from work w 
join museum m on m.museum_id = w.museum_id
group by m.name order by 2
--3
WITH cte AS (
    SELECT *,
        CASE 
            WHEN sale_price > regular_price THEN 'expensive'
            ELSE 'fair' 
        END as category
    FROM product_size
)
SELECT COUNT(*) 
FROM cte 
WHERE category = 'expensive';

select count(*) from product_size where sale_price>regular_price;

--4
WITH cte AS (
    SELECT *,
        CASE 
            WHEN sale_price > regular_price THEN 'expensive'
            when sale_price < regular_price * 0.5 then 'dirt cheap'
			else 'whatever'
        END as category
    FROM product_size
)
SELECT COUNT(*) 
FROM cte 
WHERE category = 'dirt cheap';


select count(*) from product_size where sale_price < (regular_price * 0.5);
--5
SELECT w.name, p.sale_price
FROM product_size p 
JOIN canvas_size c ON p.size_id = c.size_id::text
join work w on w.work_id = p.work_id order by 2 desc
limit 5;

--6
select distinct * from work; --14776 to 14716
select distinct * from product_size; -- 110347 to 109660
select distinct * from subject; -- 6771 to 6712
select distinct * from image_link; --14775 to 14715

--7
select * from museum where city !~ '^[A-Z]'

--8

--9
select * from work;
select * from product_size;
select * from museum
select * from museum_hours
select * from artist;
select * from canvas_size
select * from subject
select * from image_link

--10

select m.name, m.city from museum m 
join  museum_hours mh on m.museum_id = mh.museum_id
where day in ('Monday', 'Sunday')
group by m.name,m.city

--11
select count(2) 
from (select museum_id, count(*) from museum_hours group by museum_id having count(2)=7)


--12
select m.name, count(*) from museum m 
join work w on m.museum_id = w.museum_id
group by m.name order by 2 desc limit 5

--13
select a.full_name, count(*) from artist a
join work w on a.artist_id = w.artist_id
group by a.full_name order by 2 desc limit 5

--14
select w.name, count(*), ps.size_id from work w 
join museum m on w.museum_id=m.museum_id
join product_size ps on w.work_id=ps.work_id
group by w.name, ps.size_id
--15

--16

with cte1 as 
(
select style, count(*), rank()over(order by count(2) desc) from work where museum_id is not null group by style
),
cte2 as 
(
select w.museum_id, m.name, cte1.style, count(1) as num_paintings from museum m
join work w on w.museum_id = m.museum_id
join cte1 on w.style = cte1.style
group by 1,2,cte1.style
)
select * from cte2 order by 4 desc limit 5

--17
select * from work;
select * from product_size;
select * from museum
select * from museum_hours
select * from artist;
select * from canvas_size
select * from subject
select * from image_link

with cte as
		(select distinct a.full_name as artist
		--, w.name as painting, m.name as museum
		, m.country
		from work w
		join artist a on a.artist_id=w.artist_id
		join museum m on m.museum_id=w.museum_id)
	select artist,count(1) as no_of_countries
	from cte
	group by artist
	having count(1)>1
	order by 2 desc;


--18


--19
select a.full_name, min(sale_price), max(sale_price), m.city from work w
join museum m on w.museum_id = m.museum_id
join artist a on w.artist_id = a.artist_id
join product_size ps on w.work_id = ps.work_id
group by a.full_name, m.name, m.city
order by


with cte as 
		(select *
		, rank() over(order by sale_price desc) as rnk
		, rank() over(order by sale_price ) as rnk_asc
		from product_size )
	select w.name as painting
	, cte.sale_price
	, a.full_name as artist
	, m.name as museum, m.city
	, cz.label as canvas
	from cte
	join work w on w.work_id=cte.work_id
	join museum m on m.museum_id=w.museum_id
	join artist a on a.artist_id=w.artist_id
	join canvas_size cz on cz.size_id = cte.size_id::NUMERIC
	where rnk=1 or rnk_asc=1;

--20
select * from work;
select * from product_size;
select * from museum
select * from museum_hours
select * from artist;
select * from canvas_size
select * from subject
select * from image_link

with cte as
(
select m.country, count(*) num, rank()over(order by count(2) desc) rnk from work w
join museum m on m.museum_id = w.museum_id
group by m.country 
order by 2 desc limit 5
)
select country,num from cte where rnk = 5


--21

with cte as
(
select style, count(*), rank() over(order by count(style) desc) rnk, count(style) over() no_of_records from work
where style is not null
group by style
)
select style,
case when rnk <=3 then 'Most Popular' else 'Least Popular' end as remarks from cte
where rnk <=3 or rnk > no_of_records -3

--22 
select a.full_name, count(*), a.nationality  from work w
join museum m on m.museum_id = w.museum_id
join artist a on a.artist_id = w.artist_id
join subject s on s.work_id = w.work_id
where m.country != 'USA' and s.subject = 'Portraits'
group by a.full_name, a.nationality
order by 2 desc limit 2




