--Task 1. Create a New Book Record -- "978-1-60129-456-2', 'To Kill a Mockingbird', 'Classic', 6.00, 'yes', 'Harper Lee', 'J.B. Lippincott & Co.')"
select * from books;
insert into books(isbn, book_title, category, rental_price,status, author, publisher)
values('978-1-60129-456-2', 'To Kill a Mockingbird', 'Classic', 6.00, 'yes', 'Harper Lee', 'J.B. Lippincott & Co.');
--Task 2: Update an Existing Member's Address
select * from members;
update members set member_address = '125 Oak St' where member_id = 'C103'
--Task 3: Delete a Record from the Issued Status Table -- Objective: Delete the record with issued_id = 'IS121' from the issued_status table.
select * from issued_status;
delete from issued_status where issued_id = 'IS121';
--Task 4: Retrieve All Books Issued by a Specific Employee -- Objective: Select all books issued by the employee with emp_id = 'E101'.
select * from issued_status where issued_emp_id = 'E101';
--Task 5: List Members Who Have Issued More Than One Book -- Objective: Use GROUP BY to find members who have issued more than one book.
select issued_emp_id, count(*) from issued_status group by issued_emp_id having count(*)>1 order by count(*)
--Task 6: Create Summary Tables: Used CTAS to generate new tables based on query results - each book and total book_issued_cnt**
select * from issued_status;
select * from books;
select b.isbn, b.book_title, count(ist.issued_id) from issued_status as ist join books as b on ist.issued_book_isbn = b.isbn group by b.isbn, b.book_title;
--Task 7. Retrieve All Books in a Specific Category:
select * from books where category = 'Classic';
--Task 8: Find Total Rental Income by Category:
select * from books;

select b.category, sum(b.rental_price), count(*) from books as b join issued_status as ist on  b.isbn = ist.issued_book_isbn group by 1;

select * from issued_status;

--List Members Who Registered in the Last 180 Days:
select * from members where reg_date >= CURRENT_DATE - interval '10 days';
--List Employees with Their Branch Manager's Name and their branch details:
select * from branch;
select * from employees;

select emp.emp_id, emp.emp_name, emp.position, emp.salary, emp2.emp_name as manager from employees as emp join branch as br on br.branch_id = emp.branch_id join employees as emp2 on emp2.emp_id = br.manager_id
--Task 11. Create a Table of Books with Rental Price Above a Certain Threshold
create table greater_rental_price_threshold as
select * from books where rental_price > 7.00;
--Task 12: Retrieve the List of Books Not Yet Returned
select * from return_status;
select * from issued_status

select * from issued_status as ist left join return_status as rs on rs.issue_id = ist.issued_id where rs.return_id is null
SELECT * FROM issued_status as ist
LEFT JOIN
return_status as rs
ON rs.issue_id = ist.issued_id
WHERE rs.return_id IS NULL;
--Task 13: Identify Members with Overdue Books
select ist.issued_member_id, m.member_name, bk.book_title, ist.issued_date, current_date - ist.issued_date as over_due_days from issued_status as ist
join books as bk on bk.isbn = ist.issued_book_isbn
join members as m on m.member_id = ist.issued_member_id
left join return_status as rs
on rs.issue_id = ist.issued_id
where rs.return_date is null
and 
(current_date-ist.issued_date)>30 order by 1
--Task 14: Update Book Status on Return
--Task 15: Branch Performance Report
--Task 16: CTAS: Create a Table of Active Members
--Task 17: Find Employees with the Most Book Issues Processed
--Task 18: Identify Members Issuing High-Risk Books
--Task 19: Stored Procedure Objective
--Task 20: Create Table As Select (CTAS) Objectiv
