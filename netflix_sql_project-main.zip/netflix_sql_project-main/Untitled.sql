select * from netflix;

--1. Count the number of Movies vs TV Shows
select
(select count(*) from netflix where type = 'TV Show'),
(select count(*) from netflix where type = 'Movie')
--2. Find the most common rating for movies and TV shows
select type, max(rating) from netflix group by type

--3. List all movies released in a specific year (e.g., 2020)
select * from netflix where release_year = 2020
--4. Find the top 5 countries with the most content on Netflix
select unnest(string_to_array(country, ',')), count(1), rank() over(order by count(2) desc) from netflix group by 1
--5. Identify the longest movie
with cte as
(
select unnest(string_to_array(duration,' ')) duration from netflix where type = 'Movie'
)
select max(duration::integer) from cte where duration != 'min'

select * from netflix where duration = '312 min'
--6. Find content added in the last 5 years
SELECT * FROM netflix 
WHERE extract(year from date_added::date) = (EXTRACT(YEAR FROM CURRENT_DATE) - 5);
--8. List all TV shows with more than 5 seasons
with cte as 
(
select *,((string_to_array(duration,' '))[1]::integer) num_season from netflix where type = 'TV Show'
)
select * from cte where num_season > 5 order by num_season asc
--9. Count the number of content items in each genre
with cte as
(
select *, unnest(string_to_array(listed_in,', ')) genre from netflix
),
cte2 as
(
select show_id, count(genre) num_genre from cte group by show_id
)
select * from cte
join cte2 on cte.show_id=cte2.show_id
--10.Find each year and the average numbers of content release in India on netflix. 
with cte as
(
select *, unnest(string_to_array(listed_in,', ')) genre from netflix
),
cte2 as
(
select show_id, count(genre) num_genre from cte group by show_id
)
select extract(year from date_added::date) ,round(avg(num_genre),2) avg_content_added from cte
join cte2 on cte.show_id=cte2.show_id where country = 'India' group by 1 order by 2 desc limit 5
--return top 5 year with highest avg content release!
--11. List all movies that are documentaries
with cte as
(
select *, unnest(string_to_array(listed_in,', ')) genre from netflix 
)
select * from cte where genre = 'Documentaries' and type = 'Movie'

--12. Find all content without a director
select * from netflix where director is null
--13. Find how many movies actor 'Salman Khan' appeared in last 10 years!
with cte as
(
select *, unnest(string_to_array(casts,', ')) film_cast from netflix
)
select * from cte where film_cast = 'Salman Khan' and type = 'Movie' and (release_year > extract(year from current_date) - 10)
--14. Find the top 10 actors who have appeared in the highest number of movies produced in India.
with cte as
(
select *, unnest(string_to_array(casts,', ')) film_cast from netflix
)
select film_cast,count(*), rank() over(order by count(*) desc) from cte where country = 'India' group by film_cast limit 10
--Categorize the content based on the presence of the keywords 'kill' and 'violence' in 
--the description field. Label content containing these keywords as 'Bad' and all other 
--content as 'Good'. Count how many items fall into each category.
SELECT *,
    CASE 
        WHEN description ILIKE '%kill%' AND description ILIKE '%violence%' THEN 'bad'
        ELSE 'good'
    END as content_rating
FROM netflix;


