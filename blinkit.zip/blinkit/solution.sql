select distinct item_fat_content from blinkit_data

update blinkit_data
set item_fat_content = initcap(item_fat_content)



update blinkit_data
set item_fat_content = 
case
when item_fat_content in ('Lf') then 'Low Fat'
when item_fat_content in ('Reg') then 'Regular'
else item_fat_content
end


-- KPI REQUIREMENTS
-- Total Sales: The overall revenue generated from all items sold.
select sum(total_sales) from blinkit_data
-- Average Sales: The average revenue per sale.
select avg(total_sales) from blinkit_data
-- Number of Items: The total count of different items sold.
select count(*) from blinkit_data
-- Average Rating: The average customer rating for items sold. 
select avg(rating) from blinkit_data


select * from blinkit_data

-- 1. Total Sales by Fat Content:
-- 	Objective: Analyze the impact of fat content on total sales.
select item_fat_content, sum(total_sales) 
from blinkit_data
group by item_fat_content
-- 	Additional KPI Metrics: Assess how other KPIs (Average Sales, Number of Items, Average Rating) vary with fat content.
select item_fat_content, sum(total_sales) total_sales, avg(total_sales) avg_total_sales, count(*) count_items, avg(rating) avg_rating
from blinkit_data
group by item_fat_content
-- 2. Total Sales by Item Type:
-- 	Objective: Identify the performance of different item types in terms of total sales.
select item_type, sum(total_sales) 
from blinkit_data
group by item_type
order by 2 desc

-- 	Additional KPI Metrics: Assess how other KPIs (Average Sales, Number of Items, Average Rating) vary with fat content.
select item_type, item_fat_content, sum(total_sales),avg(total_sales) avg_total_sales, count(*) count_items, avg(rating) avg_rating
from blinkit_data
group by item_fat_content,item_type
order by 1 desc
-- 3. Fat Content by Outlet for Total Sales:
-- 	Objective: Compare total sales across different outlets segmented by fat content.
select outlet_location_type,item_fat_content, count(item_fat_content), sum(total_sales)
from blinkit_data
group by item_fat_content,outlet_location_type
order by 1 

select * from blinkit_data

-- 	Additional KPI Metrics: Assess how other KPIs (Average Sales, Number of Items, Average Rating) vary with fat content.
select outlet_location_type,item_fat_content, count(item_fat_content), sum(total_sales),avg(total_sales) avg_total_sales, count(*) count_items, avg(rating) avg_rating
from blinkit_data
group by item_fat_content,outlet_location_type
order by 1 
-- 4. Total Sales by Outlet Establishment:
-- 	Objective: Evaluate how the age or type of outlet establishment influences total sales.
select outlet_type, sum(total_sales) 
from blinkit_data
group by 1
order by 2 desc

select outlet_establishment_year, sum(total_sales) 
from blinkit_data
group by 1
order by 2 desc
-- 5. Percentage of Sales by Outlet Size:
-- 	Objective: Analyze the correlation between outlet size and total sales.
select outlet_size, sum(total_sales) 
from blinkit_data
group by 1
order by 2 desc
-- 6. Sales by Outlet Location:
-- 	Objective: Assess the geographic distribution of sales across different locations.
select outlet_location_type, sum(total_sales) 
from blinkit_data
group by 1
order by 2 desc
-- 7. All Metrics by Outlet Type:
-- 	Objective: Provide a comprehensive view of all key metrics (Total Sales, Average Sales, Number of 	Items, Average Rating) broken down by different outlet types.
select outlet_type, sum(total_sales),avg(total_sales) avg_total_sales, count(*) count_items, avg(rating) avg_rating
from blinkit_data
group by 1
order by 1 asc