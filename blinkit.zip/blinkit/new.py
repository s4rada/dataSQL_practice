import pandas as pd
import os
from datetime import datetime

def csv_to_sql(csv_file_path, sql_file_path=None, table_name=None, delimiter=','):
    """
    Convert CSV file to SQL INSERT statements
    
    Parameters:
    - csv_file_path: Path to the CSV file
    - sql_file_path: Path to save the SQL file (optional)
    - table_name: Name for the SQL table (optional)
    - delimiter: CSV delimiter (default is ',')
    """
    
    # Generate default table name from CSV filename if not provided
    if table_name is None:
        base_name = os.path.basename(csv_file_path)
        table_name = os.path.splitext(base_name)[0].replace(' ', '_').replace('-', '_').lower()
    
    # Generate default SQL file path if not provided
    if sql_file_path is None:
        sql_file_path = os.path.splitext(csv_file_path)[0] + '.sql'
    
    try:
        # Read CSV file
        print(f"Reading CSV file: {csv_file_path}")
        df = pd.read_csv(csv_file_path, delimiter=delimiter)
        
        # Display basic info
        print(f"Shape: {df.shape[0]} rows, {df.shape[1]} columns")
        print(f"Columns: {list(df.columns)}")
        
        # Prepare SQL statements
        sql_statements = []
        
        # Add header comment
        sql_statements.append(f"-- SQL file generated from CSV: {os.path.basename(csv_file_path)}")
        sql_statements.append(f"-- Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        sql_statements.append(f"-- Total rows: {len(df)}")
        sql_statements.append("")
        
        # Create table statement
        columns_with_types = []
        for col in df.columns:
            # Try to infer SQL data type
            dtype = str(df[col].dtype)
            if 'int' in dtype:
                sql_type = 'INTEGER'
            elif 'float' in dtype:
                sql_type = 'REAL'
            elif 'datetime' in dtype or 'time' in dtype:
                sql_type = 'DATETIME'
            elif 'bool' in dtype:
                sql_type = 'BOOLEAN'
            else:
                # Check if column might be date/time
                sample_value = df[col].iloc[0] if len(df) > 0 else ''
                if isinstance(sample_value, str) and len(sample_value) > 10:
                    # Try to detect if it's a long text
                    if len(str(sample_value)) > 100:
                        sql_type = 'TEXT'
                    else:
                        sql_type = 'VARCHAR(255)'
                else:
                    sql_type = 'VARCHAR(255)'
            
            col_name = col.replace(' ', '_').replace('-', '_').replace('.', '_').lower()
            columns_with_types.append(f"    {col_name} {sql_type}")
        
        create_table_sql = f"CREATE TABLE IF NOT EXISTS {table_name} (\n"
        create_table_sql += ",\n".join(columns_with_types)
        create_table_sql += "\n);"
        
        sql_statements.append(create_table_sql)
        sql_statements.append("")
        
        # Generate INSERT statements
        print("Generating INSERT statements...")
        for index, row in df.iterrows():
            values = []
            for val in row:
                if pd.isna(val):
                    values.append('NULL')
                elif isinstance(val, (int, float)):
                    values.append(str(val))
                elif isinstance(val, str):
                    # Escape single quotes in strings
                    escaped_val = val.replace("'", "''")
                    values.append(f"'{escaped_val}'")
                elif isinstance(val, pd.Timestamp):
                    values.append(f"'{val.strftime('%Y-%m-%d %H:%M:%S')}'")
                else:
                    values.append(f"'{str(val).replace("'", "''")}'")
            
            insert_sql = f"INSERT INTO {table_name} VALUES ({', '.join(values)});"
            sql_statements.append(insert_sql)
            
            # Show progress for large files
            if (index + 1) % 1000 == 0:
                print(f"  Processed {index + 1} rows...")
        
        # Write to SQL file
        print(f"Writing SQL file: {sql_file_path}")
        with open(sql_file_path, 'w', encoding='utf-8') as sql_file:
            sql_file.write('\n'.join(sql_statements))
        
        print(f"✓ Conversion complete!")
        print(f"✓ SQL file saved to: {sql_file_path}")
        print(f"✓ Table name: {table_name}")
        print(f"✓ Total rows converted: {len(df)}")
        
        return sql_file_path, table_name, len(df)
        
    except FileNotFoundError:
        print(f"Error: CSV file not found at {csv_file_path}")
        return None
    except pd.errors.EmptyDataError:
        print("Error: CSV file is empty")
        return None
    except Exception as e:
        print(f"Error during conversion: {str(e)}")
        return None

def preview_csv(csv_file_path, n_rows=5, delimiter=','):
    """Preview the CSV file structure"""
    try:
        df = pd.read_csv(csv_file_path, delimiter=delimiter, nrows=n_rows)
        print("CSV Preview:")
        print(f"File: {csv_file_path}")
        print(f"Shape: {df.shape}")
        print(f"Columns: {list(df.columns)}")
        print(f"\nFirst {n_rows} rows:")
        print(df.head(n_rows))
        print(f"\nData types:")
        print(df.dtypes)
        return df
    except Exception as e:
        print(f"Error previewing CSV: {str(e)}")
        return None

def main():
    # Your CSV file path
    csv_file = "/Users/ron/Documents/data-practice/blinkit/BlinkIT Grocery Data.csv"
    
    if not os.path.exists(csv_file):
        print(f"Error: File not found at {csv_file}")
        # Alternative: Ask for file path
        csv_file = input("Please enter the full path to your CSV file: ").strip()
    
    # Preview the CSV first
    print("=" * 50)
    preview_csv(csv_file, n_rows=3)
    print("=" * 50)
    
    # Ask for table name
    table_name_input = input("\nEnter table name (press Enter for default): ").strip()
    table_name = table_name_input if table_name_input else None
    
    # Convert to SQL
    result = csv_to_sql(
        csv_file_path=csv_file,
        table_name=table_name,
        delimiter=','  # Change to ';' or '\t' if needed
    )
    
    if result:
        sql_file, table_name, row_count = result
        print("\n" + "=" * 50)
        print(f"SUCCESSFULLY CONVERTED!")
        print(f"SQL File: {sql_file}")
        print(f"Table Name: {table_name}")
        print(f"Rows: {row_count}")
        
        # Show sample SQL
        print("\nSample SQL statements:")
        with open(sql_file, 'r', encoding='utf-8') as f:
            lines = f.readlines()[:15]  # First 15 lines
            for line in lines:
                print(line.rstrip())

if __name__ == "__main__":
    main()